rootProject.name = "microservices-parent"

include("product-service", "order-service", "inventory-service", "discovery-service", "api-gateway")
