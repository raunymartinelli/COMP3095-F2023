CREATE DATABASE "order-service"

GRANT ALL PRIVILEGES ON DATABASE "order-service" TO "admin"